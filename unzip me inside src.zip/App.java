public class App {
    public static void main(String[] args) throws Exception {
        logingui loginObject = new logingui();

        loginObject.frontGUI();
    }
}
